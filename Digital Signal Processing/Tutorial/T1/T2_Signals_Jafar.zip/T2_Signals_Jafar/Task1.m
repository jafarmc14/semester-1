%Task 1
clc
clear
%Generate signal, samples = 512
N = 512;

%y = random('Normal',a,b,[M,N]); a=mean, b=standard deviation, 
%https://stackoverflow.com/questions/15884945/how-to-generate-random-numbers-from-a-normal-distribution-with-specific-mean-and/15884988
N1 = random('Normal',0,1,[1,N]); %mean = 0 and standard deviation = 1.0
N2 = random('Normal',2,2,[1,N]); %mean = 2 and standard deviation = 2

%you can generate N random numbers in the interval (a,b) with the formula r = a + (b-a).*rand(N,1)
%https://www.mathworks.com/help/matlab/ref/rand.html?s_tid=srchtitle_rand_1
U = 1+(3-1)*rand(N,1); %interval [1, 3]

%Plotting N1, N2, U
subplot(2,2,1)
plot(N1, 'b')
hold on
plot(N2, 'g')
hold on
plot(U, 'r')
axis([0 512 -6 8])
legend('\mu=0 and \sigma=1', '\mu=2 and \sigma=2', 'uniform=[1,3]')
title('Generated Signals')

%Plotting N1
subplot(2,2,2)
plot(N1,'b')
axis([0 500 -5 5])
title('Normal distribution, m=0, s=1')
%Plotting N2
subplot(2,2,3)
plot(N2,'g')
axis([0 500 -5 5])
title('Normal distribution, m=2, s=2')
%Plotting U
subplot(2,2,4)
plot(U,'r')
axis([0 500 -5 5])
title('Uniform distribution, [1,3]')

%calling the function
[mean_N1, std_N1] = generate_signals(N1)
[mean_N2, std_N2] = generate_signals(N2)
[mean_U, std_U] = generate_signals(U)

% N1, N2 and U are vectors of given length N
function [Mean, Deviation] = generate_signals(N)
    Mean = mean(N); %to find the mean
    Deviation = std(N); %to find the standard deviation
end

%In conclusion,
%The probabilities of the underlying process are constant, 
%but the statistics of the acquired signal change each time the experiment is repeated.
%"The Scientist and Engineer's Guide to Digital Signal Processing, Steven W. Smith, page.18"
