%Task 2
clc
clear
%Generate signal, samples = 512
N = 512;

%y = random('Normal',a,b,[M,N]); a=mean, b=standard deviation, 
%https://stackoverflow.com/questions/15884945/how-to-generate-random-numbers-from-a-normal-distribution-with-specific-mean-and/15884988
N1 = random('Normal',0,1,[1,N]); %mean = 0 and standard deviation = 1.0
N2 = random('Normal',2,2,[1,N]); %mean = 2 and standard deviation = 2

%you can generate N random numbers in the interval (a,b) with the formula r = a + (b-a).*rand(N,1)
%https://www.mathworks.com/help/matlab/ref/rand.html?s_tid=srchtitle_rand_1
U = 1+(3-1)*rand(N,1); %interval [1, 3]

%Calling the function RM and RS of each Signal
[RMN1,RSN1] = running_statistics(N1);
[RMN2,RSN2] = running_statistics(N2);
[RMU,RSU] = running_statistics(U);

%Plotting running mean RMN1
figure(1);
subplot(2,2,1)
plot(RMN1,'b');
title('Running Mean of N1');

%Plotting running mean RSN1
subplot(2,2,2)
plot(RSN1,'b');
title('Running Standard Deviation of N1');

%Plotting running mean U
figure(2)
subplot(2,2,1)
plot(RMN2,'g');
title('Running Mean of N2');

%Plotting running deviation N1
subplot(2,2,2)
plot(RSN2,'g');
title('Running Standard Deviation of N2');

%Plotting running deviation N2
figure(3);
subplot(2,2,1)
plot(RMU,'r');
title('Running Mean of U');

%Plotting running deviation U
subplot(2,2,2)
plot(RSU,'r');
title('Running Standard Deviation of U');

% RM is the vector of running mean
% RS is the vector of running standard deviation
function [RM, RS] = running_statistics(x)
  % prepare output vectors
  RM = zeros(size(x));
  RS = zeros(size(x));

  % calculate running statistics
  for i = 1:length(x) %for i=1 to lenght of x
    RM(i) = mean(x(1:i)) %to calculate the mean of each vector (i = to specific range)
    RS(i) = std(x(1:i)) %to calculate the standard deviation of each vector (i = to specific range)
  end
end
