%Task 4
clc
clear

%Calling the function
graph1 = generate(1)
graph2 = generate(2)
graph3 = generate(4)
graph4 = generate(6)
graph5 = generate(8)
graph6 = generate(10)

figure(1)
%Plotting graph1
subplot(2,2,1)
histogram (graph1)
title ('Adding 1')

%Plotting graph2
subplot(2,2,2)
histogram (graph2)
title ('Adding 2')

%Plotting graph3
subplot(2,2,3)
histogram (graph3)
title ('Adding 4')

figure(2)
%Plotting graph4
subplot(2,2,1)
histogram (graph4)
title ('Adding 6')

%Plotting graph5
subplot(2,2,2)
histogram (graph5)
title ('Adding 8')

%Plotting graph6
subplot(2,2,3)
histogram (graph6)
title ('Adding 10')

% res is the output vector
% mult is the number of values added (1, 2, 4, 6, 8)
function res = generate(mult)
  res = zeros(size(128)) %to store  the result
  %you can generate N random numbers in the interval (a,b) with the formula r = a + (b-a).*rand(N,1)
  %https://www.mathworks.com/help/matlab/ref/rand.html?s_tid=srchtitle_rand_1
  signal = 0+(1-0)*rand(128*mult,1);%to generate uniform distribution with adding, interval [0, 1] 
  count = 1 %setting the counter = 1
  for i = 1:128 %loop from 1 to 128
      x = count + (mult - 1) %specifying the number of vectors to add
      res(i) = sum(signal(count:x)) %Adding the signal in a specific interval 
      %https://www.mathworks.com/matlabcentral/answers/575290-adding-the-signal-in-a-specific-interval
      count = count + mult %to increase the counter
  end
end

%In conclusion,
%The more additions the signal shape will approach the Normal Distribution
%because normal distribution is where probability of x in highest at the
%center and lowest at the end
