%Task 3
clc
clear
%Generate signal, samples = 512
N = 512;

%y = random('Normal',a,b,[M,N]); a=mean, b=standard deviation, 
%https://stackoverflow.com/questions/15884945/how-to-generate-random-numbers-from-a-normal-distribution-with-specific-mean-and/15884988
N1 = random('Normal',0,1,[1,N]); %mean = 0 and standard deviation = 1.0
N2 = random('Normal',2,2,[1,N]); %mean = 2 and standard deviation = 2

%you can generate N random numbers in the interval (a,b) with the formula r = a + (b-a).*rand(N,1)
%https://www.mathworks.com/help/matlab/ref/rand.html?s_tid=srchtitle_rand_1
U = 1+(3-1)*rand(N,1); %interval [1, 3]

%Plotting N1, N2 and U with 10 bin
figure(1)
subplot(2,2,1)
h_N1 = histogram(N1, 10, 'FaceColor','blue')
axis([-4 4 0 200]);
title('histogram of N1. 10 bins')
subplot(2,2,2)
h_N2 = histogram(N2, 10, 'FaceColor','red')
axis([-10 10 0 200]);
title('histogram of N2. 10 bins')
subplot(2,2,3)
h_U = histogram(U, 10, 'FaceColor','green')
axis([0 4 0 100]);
title('histogram of U. 10 bins')

%Plotting N1, N2 and U with 90 bin
figure(2)
subplot(2,2,1)
h_N1 = histogram(N1, 90, 'FaceColor','blue')
axis([-4 4 0 20]);
title('histogram of N1. 90 bins')
subplot(2,2,2)
h_N2 = histogram(N2, 90, 'FaceColor','red')
axis([-10 10 0 30]);
title('histogram of N2. 90 bins')
subplot(2,2,3)
h_U = histogram(U, 90, 'FaceColor','green')
axis([0 4 0 20]);
title('histogram of U. 90 bins')
