%task1
clc
clear

%Generate rectangular signal
sample = 1000;
period = 200;
amplitude = 1;
duty = 50; %duty cycle
f = 1/period; %frequency = 1 / period
t = 0:1:sample;
%https://www.mathworks.com/help/signal/ref/square.html?s_tid=doc_ta
rec = amplitude * square(2*pi*f*t,duty); %rectangular signal 

%Plotting rectangular signal
plot(t, rec, 'b')
hold on

%Add Gaussian noise to rectangular signal
mean = 0;
sigma = 0.1;
%https://www.mathworks.com/matlabcentral/answers/253208-add-gaussian-distributed-noise-with-mean-and-variance-to-matrix
rec_gas = rec + sigma * randn(size(rec)) + mean; %rectangular signal and gaussian noise

%Plotting rectangular signal with gaussian noise
plot(rec_gas,'r')
title('Rectangular signal with gaussian noise')
axis([0 1000 -1.5 1.5]);


