%task2
clc
clear

%Generate rectangular signal
sample = 1000;
period = 200;
amplitude = 1;
duty = 50; %duty cycle
f = 1/period; %frequency = 1 / period
t = 0:1:sample;
%https://www.mathworks.com/help/signal/ref/square.html?s_tid=doc_ta
rec = amplitude * square(2*pi*f*t,duty); %rectangular signal 

F1 = [1/3 1/3 1/3];%averaging filter
F2 = [1/4 1/2 1/4];%gaussian filter
F3 = [-1 0 1];%edge detecting filter

%Add Gaussian noise to rectangular signal
mean = 0;
sigma = 0.1;
%https://www.mathworks.com/matlabcentral/answers/253208-add-gaussian-distributed-noise-with-mean-and-variance-to-matrix
rec_gas = rec + sigma * randn(size(rec)) + mean; %rectangular signal and gaussian noise

%Convolve input signal A with each of the filters 1X3
conv_F1 = conv(rec_gas, F1, "same");%same=Central part of the convolution of the same size as u, conv(u,v,shape)
conv_F2 = conv(rec_gas, F2, "same");
conv_F3 = conv(rec_gas, F3, "same");

%Expand filters to a bigger size 1x5
new_F1 = [1/3 1/3 1/3 1/3 1/3];%averaging filter
new_F1 = new_F1/sum(new_F1)%normalized
new_F2 = [1/16 1/4 3/8 1/4 1/16];%gaussian filter + edited
new_F2 = new_F2/sum(new_F2)%normalized
new_F3 = [-1 0 0 0 -1];%edge detecting filter + edited
new_F3 = new_F3/sum(new_F3)%normalized

%Convolve input signal A with each of the filters 1X5
newconv_F1 = conv(rec_gas, new_F1, "same");%same=Central part of the convolution of the same size as u, conv(u,v,shape)
newconv_F2 = conv(rec_gas, new_F2, "same");
newconv_F3 = conv(rec_gas, new_F3, "same");

%task3
%Convolution 1x3 using function
func_F1 = convolution_(rec_gas, F1);
func_F2 = convolution_(rec_gas, F2);
func_F3 = convolution_(rec_gas, F3);

%Convolution 1x5 using function
func_F1_5 = convolution_(rec_gas, new_F1);
func_F2_5 = convolution_(rec_gas, new_F2);
func_F3_5 = convolution_(rec_gas, new_F3);

%Plotting the Convolve of input signal A with Average Filter
figure (1)
subplot(2, 2, 1);
plot(t, conv_F1,'b');
title ("Average Filter 1x3")
axis([0 1000 -1.5 1.5])

subplot(2, 2, 2);
plot(t, newconv_F1,'b');
title ("Average Filter 1x5")
axis([0 1000 -1.5 1.5])

tF1 = 1:1:length(func_F1);
subplot(2, 2, 3);
plot(tF1, func_F1,'b')
title ("Average Filter 1x3 using Function")
axis([0 1000 -1.5 1.5])

tF1 = 1:1:length(func_F1_5);
subplot(2, 2, 4);
plot(tF1, func_F1_5,'b')
title ("Average Filter 1x5 using Function")
axis([0 1000 -1.5 1.5])

%Plotting the Convolve of input signal A with Gaussian Filter
figure (2)
subplot(2, 2, 1);
plot(t, conv_F2,'g');
title ("Gaussian Filter 1x3")
axis([0 1000 -1.5 1.5])

subplot(2, 2, 2);
plot(t, newconv_F2,'g');
title ("Gaussian Filter 1x5")
axis([0 1000 -1.5 1.5])

tF2 = 1:1:length(func_F2);
subplot(2, 2, 3);
plot(tF2, func_F2,'g')
title ("Gaussian Filter 1x3 using Function")
axis([0 1000 -1.5 1.5])

tF2 = 1:1:length(func_F2_5);
subplot(2, 2, 4);
plot(tF2, func_F2_5,'g')
title ("Gaussian Filter 1x5 using Function")
axis([0 1000 -1.5 1.5])

%Plotting the Convolve of input signal A with Edge-detecting Filter using function
figure (3)
subplot(2, 2, 1);
plot(t, conv_F3,'r');
title ("Edge-detecting Filter 1x3")
axis([0 1000 -1.5 1.5])

subplot(2, 2, 2);
plot(t, newconv_F3,'r');
title ("Edge-detecting Filter 1x5")
axis([0 1000 -1.5 1.5])

tF3 = 1:1:length(func_F3);
subplot(2, 2, 3);
plot(tF3, func_F3,'r')
title ("Edge-detecting Filter 1x3 using Function")
axis([0 1000 -1.5 1.5])

tF3 = 1:1:length(func_F3_5);
subplot(2, 2, 4);
plot(tF3, func_F3_5,'r')
title ("Edge-detecting Filter 1x5 using Function")
axis([0 1000 -1.5 1.5])

function [convolution] = convolution_(u,v)
%https://www.mathworks.com/help/matlab/ref/conv.html
    m = length(u);
    n = length(v);
    Y = zeros(1, m+n-1);
    for i = 1:n
        for j = 1:m
            Y(i+j-1) = Y(i+j-1) + u(j) * v(i);
        end
    end
    convolution = Y
end

%What are the results? %What is the goal of each type of filter?
%1.The average filter is a signal(image) smoothing filter. 
%The basic way behind the filter is for each signal element to take an
%average in its environment. Overall, the noise of signal output be
%smoother.

%2.The gaussian filter is a smooting filter, used to `blur' images and remove detail and noise. 
%It uses a different kernel representing the Gaussian hump shape
%(`bell-shaped'). In conclusion, the gaussian filter makes noise smoother
%signal output.

%3.The edge detecting filter is a method to identify edges and curves in a
%digital image / signal. Overall, the filter detects each edge of the
%signal output.

%What happens, if filters are not normalized?
%If filters are not normalized then the output signal will overlap from the amplitude of output

%What is the difference in result between 3 and 5 element filters?
%we will get a better or smoother result if we use the more filter, such as the Gaussian filter 1x5 makes the output signal smoother than filter 1x3

%the own convolution function produces the same result / output signal with the conv() function from matlab