clc
clear

% System parameters
Fs = 1000;       % Sampling frequency [Hz]
T = 1/Fs;        % Sampling time step [s]
s = 2;           % Signal length [s]
L = s*Fs;        % Signal length (number of samples)
t = (0:L-1)*T;   % Time base
f = 0:1/s:Fs/2;  % Frequency base

% sigma value
sigma = 0.5;

x1 = generate_signal(L, t, sigma); %generate signal with noise
[Y1, A1, P1] = FFT(x1, L); %apply FFT
[Amp1, Freq1, Phase1] = values(Y1, A1, P1); %find dominant 

%recontruction of signals
r1 = (sum(Amp1' .* cos(2 * pi * Freq1' * t + Phase1')));

figure;
tiledlayout(3,1);
%plotting of noisy and reconstructed
nexttile;
plot(x1, 'b');
hold on;
plot(r1, 'r');
hold off;
title('Original and Reconstruction ,sigma=0.1');
%plotting of amplitude and frequency
nexttile; 
plot(f, A1,'b'); 
title('Amplitude and Frequency (Hz), sigma=0.1');
%plotting of phase and frequency
nexttile; 
plot(f, P1, 'g'); 
title ('Phase and Frequency (Hz), sigma=0.1');

%function to generate signal with noise
function x = generate_signal(L, t, sigma)
    % Signal creation
    N = 3;               % Number of signals
    A = [1.0   0.4  0.8] % Amplitude
    B = [ 15    27   83] % Frequency [Hz]
    C = [  0 -pi/3 pi/7] % Phase shift
    x = (sum(A' .* cos(2 * pi * B' * t + C')))'+ (sigma * randn(L, 1));
end

%function to analyze signal using fft
function [Y, A, P] = FFT(x, L)
    Y = fft(x);     % Fast Fourier Transform
    A = abs(Y);     % Amplitude
    A = A/L;        % Amplitude normalization
    A = A(1:L/2+1); % Cut important part 
    A(2:end-1) = 2*A(2:end-1);
    P = angle(Y);   % Phase
    P = P(1:L/2+1); % Cut important part
end

%function to find dominant amplitude, frequency and phase
function [Amplitude, Frequency, PhaseShift] = values (Y, A, P)
    [Amp,Freq]= sort(A); %sorted in ascending order 
    for i = 1:3
            j=i+998; %to find the biggest values
            F(i) = Freq(j); 
            Amplitude(i) = Amp(j);  
            Frequency(i) = (F(i));  
            PhaseShift(i) = P(F(i));   
    end
end

