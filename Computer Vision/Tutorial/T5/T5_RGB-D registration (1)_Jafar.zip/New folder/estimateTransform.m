function [R, T] = estimateTransform(p1, p2)
% ESTIMATETRANSFORM Estimate rigid ransform between two sets of 3D points
% 
% The estimated transform should be the best fit between the given set of
% points, i.e. p1 * R + T should be (almost) equal to p2
%
% Inputs:
%   p1 : first set of 3D points (stored as a row-vectors)
%   p2 : second set of 3D points (stored as a row-vectors)
%
% Outputs:
%   R : rotation matrix (3x3 in MATLAB format)
%   T : translation vector (single row)

    % prepare output values
    R = eye(3);
    T = [0, 0, 0];

	% =[ your code starts here ]===========================================
    %https://www.mathworks.com/matlabcentral/answers/3862-fit-rigid-body-to-points
    % Calibration:
    M0 = p1 - mean(p1);
    % Best fit:
    T = mean(p2) - mean(M0);
    R = transpose(p2 - mean(p2)) * (M0) / numel(p1);
    % Consider noise:
    [U, S, V] = svd(R);
    if det(U * V) > 0
      R = U * transpose(V);
    else
      R = U * [1,0,0; 0,1,0; 0,0,-1] * transpose(V);
    end
    % =[ your code ends here ]=============================================
    
end

