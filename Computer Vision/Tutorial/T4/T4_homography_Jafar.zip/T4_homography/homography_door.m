clc
clear
close all

% load sample image
I =imread('door.jpg');

% show the image and wait for the points selection (be sure to check if exactly four points were selected)
figure (1)
subplot (1,3,1);
imshow(I) ;
hold on

%[pix,piy] = getpts
pix = [94.31 498.43 434.52 121.11];
piy = [59.26 79.88 762.35 758.23];
pox = [10 280 280 10];
poy = [10 10  610 610];

points_in = [pix; piy]; % fill with appropriate output of the getpts command
points_out = [pox; poy];

% calculate the homography - this function should be implemented by you
H = calculate_homography(points_in, points_out, pox, poy);

% prepare image reference information
Rin = imref2d(size(I));

% convert homography matrix to the Matlab projective transformation
t = projective2d(H');

% warp the image and get the output reference information
[I2, Rout]=imwarp(I, Rin, t);
subplot (1,3,2);
imshow(I2);

% crop the output based on the reference information
I3 = crop_image(I2, Rout, pox, poy);
subplot (1,3,3);
imshow (I3)

function [H] = calculate_homography(pin, pou, X, Y)
    %https://math.stackexchange.com/questions/494238/how-to-compute-homography-matrix-h-from-corresponding-points-2d-2d-planar-homog

    %looping for make matrix
    for i=1:1:size(pin,2)
        Hx(i,:)=[pin(1,i) pin(2,i) 1 0 0 0 -pin(1,i)*pou(1,i) -pin(2,i)*pou(1,i)];
        Hy(i,:)=[0 0 0 pin(1,i) pin(2,i) 1 -pin(1,i)*pou(2,i) -pin(2,i)*pou(2,i)];
    end
    
    C=[Hx;Hy];
    
    %transpose
    Hout=[X Y]'; 
    
    %normalized
    hcom=C\Hout;
    
    %Homography matrix
    H=[hcom(1) hcom(2) hcom(3);hcom(4) hcom(5) hcom(6);hcom(7) hcom(8) 1];
end

function [I]=crop_image(I1, Rout, X, Y)
    %crooping for the last result
    %To get the coordinate of rectangle (Xtopleft,Ytl) (Xbottomright,Xbl), with additional border 10px
    a=(X(1)-Rout.XWorldLimits(1)-10);
    b=(Y(1)-Rout.YWorldLimits(1)-10);
    c=(X(3)-Rout.XWorldLimits(1)+10);
    d=(Y(3)-Rout.YWorldLimits(1)+10);
    %https://www.mathworks.com/help/images/ref/imcrop.html
    %Crop image, specifying crop rectangle
    I=imcrop(I1,[a b c-a d-a]);
end