clc;
clear;

I1=imread('974-1.jpg');
I2=imread('975-1.jpg');

% show the image and wait for the points selection (be sure to check if exactly four points were selected)
% 
% figure;
% imshow(I1);
% [x,y] = getpts;

%output
x2 = [524.93 524.93 664.7 663.56];
y2 = [251.06 310.15 314.7 253.34];

% figure;
% imshow(I2);
% [x,y] = getpts;

%input
x1 = [16.97  14.7   160.15 159.02];
y1 = [260.15 321.52 330.61 269.25];

pin  = [x1;y1];
pout = [x2;y2];

H = calculate_homography(pin, pout, x2, y2);

% prepare image reference information
Rin=imref2d(size(I2));

% convert homography matrix to the Matlab projective transformation
t = projective2d(H');

% warp the image and get the output reference information
[I3, Rout]=imwarp(I2, Rin, t);
figure;
imshow(I3)

p = imfuse(I1, Rin, I3, Rout,'diff');
% figure;
% imshow(p);
% [x,y] = getpts;

xn = [523.00 664.00 665.00 523.00];
yn = [413.00 416.00 473.00 471.00];

% xn = [523.08 664.03 665.53 523.08];
% yn = [413.48 416.48 473.47 471.97];

%ypoint = (height1 + height2)/2
ypoint=(58.49+56.99)/2;
%xpoint = (width1 + width2)/2
xpoint=(140.96+142.45)/2;

Xnew=[xn(1) xn(1)+xpoint xn(1)+xpoint xn(1)];
Ynew=[yn(1) yn(1)        yn(1)+ypoint yn(1)+ypoint];

pin2=[xn;yn];
pou2=[Xnew;Ynew];

% calculate the homography

H2 = calculate_homography(pin2, pou2,Xnew,Ynew);

% prepare image reference information

Rin2=imref2d(size(p));

% convert homography matrix to the Matlab projective transformation

t2 = projective2d(H2');

% warp the image and get the output reference information

[Inew, Rout2]=imwarp(p, Rin2, t2);
figure;
imshow(Inew);


function [H] = calculate_homography(pin, pou, X, Y)
    %https://math.stackexchange.com/questions/494238/how-to-compute-homography-matrix-h-from-corresponding-points-2d-2d-planar-homog

    %looping for make matrix
    for i=1:1:size(pin,2)
        Hx(i,:)=[pin(1,i) pin(2,i) 1 0 0 0 -pin(1,i)*pou(1,i) -pin(2,i)*pou(1,i)];
        Hy(i,:)=[0 0 0 pin(1,i) pin(2,i) 1 -pin(1,i)*pou(2,i) -pin(2,i)*pou(2,i)];
    end
    
    C=[Hx;Hy];
    
    %transpose
    Hout=[X Y]'; 
    
    %normalized
    hcom=C\Hout;
    
    %Homography matrix
    H=[hcom(1) hcom(2) hcom(3);hcom(4) hcom(5) hcom(6);hcom(7) hcom(8) 1];
end