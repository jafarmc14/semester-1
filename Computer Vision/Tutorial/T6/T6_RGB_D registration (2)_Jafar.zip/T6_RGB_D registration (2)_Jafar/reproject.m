function XYZ = reproject(depth, scale, fx, fy, cx, cy)
% REPROJECT Reproject depth values to 3D coordinates using camera
% intrinsic parameters
%   
% Inputs:
%   depth  : depth map image 
%   scale  : depth scaling factor
%   fx, fy : focal lengths
%   cx, cy : principal point

    % convert depth values to real numbers
    depth = double(depth);

    % create the X, Y and Z arrays of the same size as the input image
    X = zeros(size(depth));
    Y = zeros(size(depth));
    
    % Z coordinate is read directly from the depth image by scaling it
    Z = depth / scale;
    % =[ your code starts here ]===========================================
    for j=1:height(depth) %y
		for i=1:width(depth) %x
			X(j,i) = ((i - cx)* Z(j,i)) / fx;
		end
    end
    for j=1:height(depth) %y
		for i=1:width(depth) %x
			Y(j,i) = ((j - cy)* Z(j,i)) / fy;
		end
    end  
    % =[ your code ends here ]=============================================
    
    % create the resulting MxNx3 matrix storing the XYZ coordinates for
    % every point
    XYZ = X;
    XYZ(:,:,2) = Y;
    XYZ(:,:,3) = Z;
end

