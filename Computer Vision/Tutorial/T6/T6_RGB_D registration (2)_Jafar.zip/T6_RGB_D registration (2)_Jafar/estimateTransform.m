function [R, T] = estimateTransform(p1, p2)
% ESTIMATETRANSFORM Estimate rigid ransform between two sets of 3D points
% 
% The estimated transform should be the best fit between the given set of
% points, i.e. p1 * R + T should be (almost) equal to p2
%
% Inputs:
%   p1 : first set of 3D points (stored as a row-vectors)
%   p2 : second set of 3D points (stored as a row-vectors)
%
% Outputs:
%   R : rotation matrix (3x3 in MATLAB format)
%   T : translation vector (single row)

    % prepare output values
    R = eye(3);
    T = [0, 0, 0];

	% =[ your code starts here ]===========================================
    %1compute weighted centroids of p1 and p2
    %Suposing all of the weight are 1.
    p1_new = mean(p1);
    p2_new = mean(p2);
    
    %Compute the centered vectors
    for i=1:length(p1)
		x(i,:) = p1(i,:) - p1_new; 
		y(i,:) = p2(i,:) - p2_new;
    end
    
    %Compute covariace matrix S = XWY'
    s = x' * y; 
    
    %Calculate R
    [U,S,V] = svd(s);
    R = V *[1 0 0;0 1 0; 0 0 (det(V*U'))] * U';
    R = R';
    
    %Calculate t
    T = p2_new - (p1_new*R);
    
    % =[ your code ends here ]=============================================
    
end

