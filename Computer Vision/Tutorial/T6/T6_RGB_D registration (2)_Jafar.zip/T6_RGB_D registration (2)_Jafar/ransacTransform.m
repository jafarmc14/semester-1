function [R, T] = ransacTransform(pts1, pts2, iter, ratio, thr)
% RANSACTRANSFORM Estimate the best transform R, T between the two given 
% point sets, such that pts1 * R + T are as close to pts2 as possible
%
% Inputs:
%   pts1 : first set of points, of size Nx3
%   pts2 : second set of points, of size Nx3
%   iter : maximum number of RanSaC iterations
%   ratio: inliers ratio for the transformation to be treated as good [0..1]
%   thr  : threshold between the points to be treated as the inlier (in meters)

    % prepare output values
    R = eye(3);
    T = [0, 0, 0];
    
    % number of point pairs
    N = size(pts1, 1);
    
    for i = 1:iter    
	% =[ your code starts here ]===========================================
        [p1, p2] = pickRandomPoints(3, pts1, pts2);
        
        [Rtmp(i).data, Ttmp(i).data] = estimateTransform(p1, p2);
             
        pts_new = pts1 * Rtmp(i).data + Ttmp(i).data;
        
        differ = sqrt(sum(pts_new - pts2, 2).^2);
        
		inliers(i) = sum(differ < thr);
                
        inliers_p(i) = inliers(i) / length(pts1);
        
		if(inliers_p(i) > ratio)
            R = Rtmp(i).data;
            T = Ttmp(i).data;
            break
        end
        if (inliers_p(i) < ratio) && i==iter
            [X,N] = max(inliers_p);
            R = Rtmp(N).data;
            T = Ttmp(N).data;
        end
    % =[ your code ends here ]=============================================
    end
end

