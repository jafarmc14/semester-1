#!/bin/bash
#Variables to detect lower upper recursive and subdirectories
l=0 
u=0
rl=0
ru=0
rsl=0
rsu=0

while [ ! -z $1 ];do  
   file="$1"
   if [ $# -eq 0 ];then
      echo 'Syntax error, to see the proper use of the command please type: chname [-h|--help] '
      exit 1
 
   elif [[ $file == "-r" ]] || [[ $file == "--recursive" ]];then 
      shift
      file="$1"
      if [[ $file == "-s" ]] || [[ $file == "--subdirectories" ]];then
         shift
         file="$1"
         if [[ $file == "-l" ]] || [[ $file == "--lowercase" ]];then
            rsl=1
            break
         elif [[ $file == "-u" ]] || [[ $file == "--uppercase" ]];then
            rsu=1
            break
         fi
      elif [[ $file == "-l" ]] || [[ $file == "--lowercase" ]];then
         rl=1
         break
      elif [[ $file == "-u" ]]|| [[ $file == "--uppercase" ]];then
         ru=1
         break
      fi
   
   elif [[ $file == "-l" ]] || [[ $file == "--lowercase" ]];then
      l=1
      break
     
   elif [[ $file == "-u" ]] || [[ $file == "--uppercase" ]];then
      u=1
      break
        
   elif [[ $file == "-h" ]] || [[ $file == "--help" ]];then
      echo 'This command change the name of files  '
      echo '-l|--lowercase  lowerizing file and directory names' 
      echo 'example chname -l FILE1 DIR1 -- file1 dir1'
      echo ''     
      echo '-u|--uppercase  uppercasing file and directory names' 
      echo 'example chname -u file1 dir1 -- FILE1 DIR1'
      echo '' 
      echo '-r|--recursive  change name to all of the files in current directory'
      echo '   add -s|--subdirectories for recursive in subdirectories' 
      echo 'example chname -r -l FILE1 DIR1'
      echo 'example chname -r -s -l file1 file2 dir1 dir2' 
      echo '' 
      break
         
   else 
      echo 'Syntax error, to see the proper use of the command please type: chname [-h|--help] '
   fi
    
    shift
done


shift
while [ ! -z $1 ];do 
   file="$1"
   subfile="$1"
   if [ $l -eq 1 ];then #lowercase
      if [ -d $file ];then #lowerizing the directory
         lowercase=$(echo $file | tr '[A-Z]' '[a-z]'])
         if [ -d $lowercase ];then
               echo $file ' --keeps with the same name'
         else
            /bin/mv $file $lowercase
            echo $file ' --has been renamed as' $lowercase
         fi
      elif [ -f $file ];then #lowerizing the file
         lowercase=$(echo $file | tr '[A-Z]' '[a-z]'])
         if [ -f $lowercase ];then
               echo $file ' --keeps with the same name'
         else
            /bin/mv $file $lowercase
            echo $file ' --has been renamed as' $lowercase
         fi 
      else
         echo $file ' --this file or directory does not exist'
      fi #end lowercase
   
   elif [ $u -eq 1 ];then #uppercase
      if [ -d $file ];then #uppercasing the directory
         uppercase=$(echo $file | tr '[a-z]' '[A-Z]'])
         if [ -d $uppercase ];then
               echo $file ' --keepswith the same name'
         else
            /bin/mv $file $uppercase
            echo $file ' --has been renamed as' $uppercase
         fi 
      elif [ -f $file ];then #uppercasing the file
         uppercase=$(echo $file | tr '[a-z]' '[A-Z]'])
         if [ -f $uppercase ];then
               echo $file ' --keeps with the same name'
         else
            /bin/mv $file $uppercase
            echo $file ' --has been renamed as' $uppercase
         fi 
      else
         echo $file ' --this file or directory does not exist'
      fi #end uppercase
   
   elif [ $rl -eq 1 ];then #recursive lowercase
      if [ -f $file ];then
         lowercase=$(echo $file | tr '[A-Z]' '[a-z]'])
         if [ -f $lowercase ];then
               echo $file ' --keeps with the same name'
         else
            /bin/mv $file $lowercase
            echo $file ' --has been renamed as' $lowercase
         fi 
      elif [ -d $file ];then
         cd $file
         for f in *;do
            if [ -f $f ];then
               lowercase=$(echo $f | tr '[A-Z]' '[a-z]'])
               if [ -f $lowercase ];then
                  echo $f ' --keeps with the same name'
               else
                  /bin/mv $f $lowercase
                  echo $f ' --has been renamed as' $lowercase
               fi 
            elif [ -d $f ];then
               lowercase=$(echo $f | tr '[A-Z]' '[a-z]'])
               if [ -d $lowercase ];then
                  echo $f ' --keeps with the same name'
               else
                  /bin/mv $f $lowercase
                  echo $f ' --has been renamed as' $lowercase
               fi 
            fi
         done
         cd -
      else
         echo $file ' --this file or directory does not exist'
      fi #end recursive lowercase
      
    
   elif [ $ru -eq 1 ];then #recursive uppercase
      if [ -f $file ];then
         uppercase=$(echo $file | tr '[a-z]' '[A-Z]'])
         if [ -f $uppercase ];then
            echo $file ' --keeps with the same name'
         else
            /bin/mv $file $uppercase
            echo $file ' --has been renamed as' $uppercase
         fi 
      elif [ -d $file ];then
         cd $file
         for f in *;do
            if [ -f $f ];then
               uppercase=$(echo $f | tr '[a-z]' '[A-Z]'])
               if [ -f $uppercase ];then
                  echo $f ' --keeps with the same name'
               else
                  /bin/mv $f $uppercase
                  echo $f ' --has been renamed as' $uppercase
               fi 
            elif [ -d $f ];then
               uppercase=$(echo $f | tr '[a-z]' '[A-Z]'])
               if [ -d $uppercase ];then
                  echo $f ' --keeps with the same name'
               else
                  /bin/mv $f $uppercase
                  echo $f ' --has been renamed as' $uppercase
               fi 
            fi
         done
         cd -
      else
         echo $file ' --this file or directory does not exist'
      fi #end recursive uppercase
      
      
   elif [ $rsl -eq 1 ];then #recursive subdirectory lowercase
      if [ -f $file ];then
         lowercase=$(echo $file | tr '[A-Z]' '[a-z]'])
         if [ -f $lowercase ];then
               echo $file ' --keeps with the same name'
         else
            /bin/mv $file $lowercase
            echo $file ' --has been renamed as' $lowercase
         fi 
      elif [ -d $file ];then
         cd $file
         for f in *;do
            if [ -f $f ];then
               lowercase=$(echo $f | tr '[A-Z]' '[a-z]'])
               if [ -f $lowercase ];then
                  echo $f ' --keeps with the same name'
               else
                  /bin/mv $f $lowercase
                  echo $f ' --has been renamed as' $lowercase
               fi 
            elif [ -d $f ];then
               cd $f
		for i in *;do
		    if [ -f $i ];then
		       lowercase=$(echo $i | tr '[A-Z]' '[a-z]'])
		       if [ -f $lowercase ];then
		          echo $i ' --keeps with the same name'
		       else
		          /bin/mv $i $lowercase
		          echo $i ' --has been renamed as' $lowercase
		       fi 
		    elif [ -d $i ];then
		       lowercase=$(echo $i | tr '[A-Z]' '[a-z]'])
		       if [ -d $lowercase ];then
		          echo $i ' --keeps with the same name'
		       else
		          /bin/mv $i $lowercase
		          echo $i ' --has been renamed as' $lowercase
		       fi 
		    fi
		 done
	        cd -
            fi
         done
         cd -
      else
         echo $file ' --this file or directory does not exist'
      fi #end recursive subdirectory lowercase
   
   elif [ $rsu -eq 1 ];then #recursive subdirectory uppercase
      if [ -f $file ];then
         uppercase=$(echo $file | tr '[a-z]' '[A-Z]'])
         if [ -f $uppercase ];then
               echo $file ' --keeps with the same name'
         else
            /bin/mv $file $uppercase
            echo $file ' --has been renamed as' $uppercase
         fi 
      elif [ -d $file ];then
         cd $file
         for f in *;do
            if [ -f $f ];then
               uppercase=$(echo $f | tr '[a-z]' '[A-Z]'])
               if [ -f $uppercase ];then
                  echo $f ' --keeps with the same name'
               else
                  /bin/mv $f $uppercase
                  echo $f ' --has been renamed as' $uppercase
               fi 
            elif [ -d $f ];then
               cd $f
		for i in *;do
		    if [ -f $i ];then
		       uppercase=$(echo $i | tr '[a-z]' '[A-Z]'])
		       if [ -f $uppercase ];then
		          echo $i ' --keeps with the same name'
		       else
		          /bin/mv $i $uppercase
		          echo $i ' --has been renamed as' $uppercase
		       fi 
		    elif [ -d $i ];then
		       uppercase=$(echo $i | tr '[a-z]' '[A-Z]'])
		       if [ -d $uppercase ];then
		          echo $i ' --keeps with the same name'
		       else
		          /bin/mv $i $uppercase
		          echo $i ' --has been renamed as' $uppercase
		       fi 
		    fi
		 done
	        cd -
            fi
         done
         cd -
      else
         echo $file ' --this file or directory does not exist'
      fi #end recursive subdirectory uppercase
  
      
   else
   echo 'error' 
  
  
   fi
   
   
   
shift
done

