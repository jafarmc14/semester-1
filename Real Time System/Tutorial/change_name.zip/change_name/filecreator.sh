#!/bin/bash
#Create 2 files and 2 directories
touch FILE1 file2
mkdir -p DIR1 dir2 
#For each directory creates 2 files and 2 subdirectories
for i in */ ; do
cd $i
touch SUBFILE1 subfile2
mkdir -p SUBDIR1 Subdir2 
cd -
done
#For each subdirectory creates 2 files and 2 directories
for i in **/*/ ; do
cd $i
touch SUBSUBFILE1 subsubfile2
mkdir -p SUBSUBDIR1 subsubdir2 
cd -
done
