#!/bin/bash

bash filecreator.sh #Create the files for example

shopt -s expand_aliases
source ~/.bash_aliases

alias chname="bash ./chname.sh "

echo ''
echo 'Example of: chname -l: chname -l FILE1 file2 DIR1 dir2'
chname -l FILE1 file2 DIR1 dir2
echo ''
echo 'Example of: chname --lowecase: chname --lowercase FILE1 file2 DIR1 dir2'
chname --lowercase FILE1 file2 DIR1 dir2
echo ''
echo 'Example of: chname -u: chname -u FILE1 file2 DIR1 dir2'
chname -u FILE1 file2 DIR1 dir2
echo ''
echo 'Example of: chname --uppercase: chname --uppercase FILE1 file2 DIR1 dir2'
chname --uppercase FILE1 file2 DIR1 dir2
echo ''
echo 'Example of: chname -r -l: chname -r -l FILE2 file1 DIR2 dir1'
chname -r -l FILE2 file1 DIR2 dir1
echo ''
echo 'Example of: chname -r --upper: chname -r --upper file1 file2 DIR2 dir1 '
chname -r --uppercase file1 file2 DIR2 dir1 
echo ''
echo 'Example of chname --recursive -s --lowercase :chname --recursive -s --lowercase FILE1 FILE2 DIR2 dir1'
chname --recursive -s --lowercase FILE1 FILE2 DIR2 dir1
echo ''
echo 'Example of chname --recursive --subdirectories --uppercase chname --recursive --subdirectories --uppercase file1 file2 DIR2 dir1'
chname --recursive --subdirectories --uppercase file1 file2 DIR2 dir1
echo ''
echo 'Example of chname -h '
chname -h
echo ''
echo 'Example of wrong use chname -v'
chname -v
echo ''
echo 'Example of chname --help'
chname --help
echo ''

